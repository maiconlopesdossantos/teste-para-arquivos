package com.devsuperior.uri2611;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Uri2611Application {
	
	public static void main(String[] args) {
		SpringApplication.run(Uri2611Application.class, args);
	}
}
