package com.devsuperior.uri2990.projections;

public interface EmpregadoDeptProjection {

	String getCpf();
	String getEnome();
	String getDnome();
}
