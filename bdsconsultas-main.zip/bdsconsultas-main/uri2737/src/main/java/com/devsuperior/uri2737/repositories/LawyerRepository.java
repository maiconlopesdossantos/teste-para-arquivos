package com.devsuperior.uri2737.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.devsuperior.uri2737.entities.Lawyer;

public interface LawyerRepository extends JpaRepository<Lawyer, Long> {

}
