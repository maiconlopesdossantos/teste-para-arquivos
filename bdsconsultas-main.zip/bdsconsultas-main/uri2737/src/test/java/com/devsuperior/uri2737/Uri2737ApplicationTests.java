package com.devsuperior.uri2737;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Uri2737ApplicationTests {

	@Test
	void contextLoads() {
	}

}
