package com.devsuperior.uri2602;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Uri2602Application {

	public static void main(String[] args) {
		SpringApplication.run(Uri2602Application.class, args);
	}
}
